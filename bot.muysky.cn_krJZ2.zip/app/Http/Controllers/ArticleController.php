<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    public function index()
    {
        $articles = Article::all();
        return response()->json($articles);
    }

    public function show($id)
    {
        $article = Article::findOrFail($id);
        return response()->json($article);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'user_id' => 'required|integer',
            'category_id' => 'nullable|integer',
            'status' => 'nullable|in:draft,published',
            'published_at' => 'nullable|date'
        ]);

        $article = Article::create($validatedData);
        return response()->json($article, 201);
    }

    public function update(Request $request, $id)
    {
        $article = Article::findOrFail($id);

        $validatedData = $request->validate([
            'title' => 'string|max:255',
            'content' => 'string',
            'user_id' => 'integer',
            'category_id' => 'nullable|integer',
            'status' => 'nullable|in:draft,published',
            'published_at' => 'nullable|date'
        ]);

        $article->update($validatedData);
        return response()->json($article);
    }

    public function destroy($id)
    {
        $article = Article::findOrFail($id);
        $article->delete();
        return response()->json(null, 204);
    }
}